# START HERE — definitive Paper 1 package

The definitive manuscript in this folder is **`paper/consecutive_artin.pdf`**;
its editable source is **`paper/consecutive_artin.tex`**. The identical named
attachment is `submission/consecutive_artin_manuscript.pdf`.

- Anonymous review PDF: `submission/consecutive_artin_anonymous.pdf`.
- Named LaTeX upload ZIP: `submission/consecutive_artin_source.zip`.
- Portable reproduction ZIP: `submission/consecutive_artin_reproduction.zip`.
- Code and generator: `code/`; corrected outputs and check logs: `results/`.
- **Machine-checked Theorem 1: `lean/`** (Lean 4 + Mathlib; source only, ~48 KB).
  Build/check instructions in `lean/BUILD.md`; scope in `lean/README_LEAN.md`.
  `lean/gate.sh` prints `PASS (19 theorems, standard axioms only)`.
- Instructions: `README.md`; verification scope: `FINAL_STATUS.md`.
- Private, unsent endorsement draft: `submission/endorsement_email_pollack.md`.
  This draft is local only and excluded from both public Git and the reproduction ZIP.

This is self-contained for manuscript building and analysis from a generated CSV,
not a bundle of the massive raw dataset. The corrected local CSV remains at
`../data_1e9.csv`; regenerate it with the included C sieve or pass its path to
`code/recompute_corrected.py`. Raw CSVs are not public or in either ZIP.

`lean/` formalizes only Theorem 1 and its `g ≡ 0 (mod 40)` companion — nothing
empirical (no δ, no z-scores, no conjecture) and no primality claims. It ships
without its `.lake/` build tree (~7.5 GB); reconstruct with `lake exe cache get`.

`archive/` contains superseded originals for provenance only; never use those
as current manuscripts. Papers 2–7 are not revised or certified by this package.
`MANIFEST.sha256` checks the local package except itself and archives.
The reproduction ZIP has its own manifest and excludes archives/correspondence.

Public repository: https://github.com/jpbald93/consecutive-artin
