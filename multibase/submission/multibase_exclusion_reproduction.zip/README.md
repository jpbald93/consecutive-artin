# Paper 2 — "Exclusion laws for consecutive Artin primes in arbitrary bases"

Latest revision: 2026-08-17, second revision (12pp): stats caveats, bootstrap CI [-0.99,-0.86],
8.82M expected-pairs calibration, lit-search paragraph, conductor-law derivation sketch,
Fig 1 curve demoted, Table 5 control % corrected (28.8/29.3).

- paper/    — .tex source, compiled PDF (12pp), figure + figure script
- code/     — multibase_delta.c (the 1e9 11-base one-pass run), classification scan +
              verification scripts, delta analysis, overfit/conductor tests
- results/  — multibase_1e9.json (full contingency data), delta_summary.json,
              scan/verify results + logs, THEOREM.md notes

No submission builds yet — target journal TBD (reviewer suggests Math. Comp. / Acta Arith / IJNT).

Public repo: https://github.com/jpbald93/consecutive-artin (multibase/ subfolder)
